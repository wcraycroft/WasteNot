package cs134.miracosta.wastenot.Model;

public enum DonationStatus
{
    UNCLAIMED,
    DONATION_CLAIMED,
    DELIVERY_CLAIMED
}
