package cs134.miracosta.wastenot.UI;

import android.view.View;

public interface OnItemClickListener {
    void onItemClick(View view, int position);
}
