package cs134.miracosta.wastenot.Model;

/**
 *
 */
public enum FoodType {
    DAIRY,
    MEAT,
    PRODUCE,
    BAKED_GOODS,
    PREPARED_PACKAGED,
    PREPARED_TRAY,
    OTHER;
}