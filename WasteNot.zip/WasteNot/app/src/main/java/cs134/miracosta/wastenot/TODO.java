/**
 *
 *  Will
 * Firebase calls:
 *    - addUser()
 *    - getUser(email)
 *    - getAllClaims()
 *    - getUserClaims(User)
 *    - convertDonationToClaim(Donation, User (claimer))
 *
 *    TODO: Add Ahmad strings.xml
 *
 *
 *
 *
 *
 * Ahmad
 *
 * TODO: Get location information from user, add location getter/setters etc. to User class
 *      Address, City, State, Zip
*  TODO: Replace Database calls with FirebaseDBHelper methods (see TestActivity for example)
 * TODO: Replace Claimer/Driver with User
 * TODO: Replace Claim/Delivery with Donation
 * TODO: Add Button in ClaimListActivity that take user to DeliveryActivity
  */





package cs134.miracosta.wastenot;

public class TODO {
}
