package cs134.miracosta.wastenot.model;

import java.io.Serializable;
import java.sql.Time;
import java.util.Objects;

public class Claim extends Donation implements Serializable {
    public Claim(Donor donor, Claimer claimer, FoodType foodType, int servings, boolean fitInCar, String otherInfo,
                 String readyTime, String pickupEndTime) {
        super(donor, claimer, foodType, servings, fitInCar, otherInfo, readyTime, pickupEndTime);
    }

    public Claim() {
    }

    private String nodeName;

    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    private String mDropOffEndTime;

    /**
     * @param donor
     * @param foodType
     * @param servings
     * @param fitInCar
     * @param otherInfo
     * @param readyTime
     * @param pickupEndTime
     * @param dropOffEndTime
     */
    /* Does not take in claimer because it will be null when we instantiate a Claim object
       and set later after the Claim is claimed. */
    public Claim(Donor donor, FoodType foodType, int servings, boolean fitInCar,
                 String otherInfo, String readyTime, String pickupEndTime, String dropOffEndTime) {
        super(donor, null, foodType, servings, fitInCar, otherInfo, readyTime, pickupEndTime);
        mDropOffEndTime = dropOffEndTime;
    }

    public String getDropOffEndTime() {
        return mDropOffEndTime;
    }

    public void setDropOffEndTime(String dropOffEndTime) {
        mDropOffEndTime = dropOffEndTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Claim claim = (Claim) o;
        return Objects.equals(mDropOffEndTime, claim.mDropOffEndTime);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), mDropOffEndTime);
    }

    @Override
    public String toString() {
        return "Claim{" +
                "Donor=" + getDonor() +
                ", Claimer=" + getClaimer() +
                ", Food Type=" + getFoodType() +
                ", Servings=" + getServings() +
                ", Fit In Car=" + isFitInCar() +
                ", Other Info='" + getOtherInfo() + '\'' +
                ", Ready Time=" + getReadyTime() +
                ", Pickup End Time=" + getPickupEndTime() +
                ", DropOff End Time=" + mDropOffEndTime +
                '}';
    }
}
