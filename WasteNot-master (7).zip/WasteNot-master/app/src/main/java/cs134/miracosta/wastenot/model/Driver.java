package cs134.miracosta.wastenot.model;

import java.util.ArrayList;

public class Driver {

    private ArrayList<Delivery> deliveryList;

    public ArrayList<Delivery> getDeliveryList() {
        return deliveryList;
    }

    public void setDeliveryList(ArrayList<Delivery> deliveryList) {
        this.deliveryList = deliveryList;
    }
}
