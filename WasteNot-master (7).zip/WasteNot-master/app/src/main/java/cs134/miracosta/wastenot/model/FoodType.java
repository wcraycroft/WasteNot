package cs134.miracosta.wastenot.model;

import java.io.Serializable;

/**
 *
 */
public enum FoodType implements Serializable {
    DAIRY,
    MEAT,
    PRODUCE,
    BAKED_GOODS,
    PREPARED_PACKAGED,
    PREPARED_TRAY,
    OTHER;
}