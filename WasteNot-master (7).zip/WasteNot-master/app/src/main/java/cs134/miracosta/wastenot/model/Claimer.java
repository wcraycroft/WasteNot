package cs134.miracosta.wastenot.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Claimer implements Serializable {
    private String companyName;
    private ArrayList<Delivery> deliveryList;

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public ArrayList<Delivery> getDeliveryList() {
        return deliveryList;
    }

    public void setDeliveryList(ArrayList<Delivery> deliveryList) {
        this.deliveryList = deliveryList;
    }
}
