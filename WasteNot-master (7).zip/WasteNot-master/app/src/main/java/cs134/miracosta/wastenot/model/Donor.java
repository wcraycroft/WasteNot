package cs134.miracosta.wastenot.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Donor implements Serializable {
    public Donor() {
    }

    public Donor(String companyName, ArrayList<Claim> claimList) {
        this.companyName = companyName;
        this.claimList = claimList;
    }

    private String companyName;

    private ArrayList<Claim> claimList;

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public ArrayList<Claim> getClaimList() {
        return claimList;
    }

    public void setClaimList(ArrayList<Claim> claimList) {
        this.claimList = claimList;
    }
}
