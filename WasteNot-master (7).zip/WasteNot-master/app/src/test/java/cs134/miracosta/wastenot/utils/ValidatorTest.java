package cs134.miracosta.wastenot.utils;

import android.text.TextUtils;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.junit.Assert.*;

@PrepareForTest({TextUtils.class})
@RunWith(PowerMockRunner.class)
public class ValidatorTest {

    @Before
    public void setUp(){
        PowerMockito.mockStatic(TextUtils.class);
    }

    @Test
    public void validateText() {
        assertTrue(Validator.validateText("text"));
        assertFalse(Validator.validateText(""));
        assertFalse(Validator.validateText(" "));
    }

    @Test
    public void validateEmail() {
        assertTrue(Validator.validateEmail("email@email.com"));
        assertFalse(Validator.validateEmail(""));
        assertFalse(Validator.validateEmail("email.com"));
    }
}